# ClarifyCoder Demo

A tiny demo of clarification-aware assistance. It exposes a FastAPI backend
that analyzes a problem statement + optional context and returns prioritized
clarification questions. A Streamlit UI calls the API.

## Quickstart

```bash
# create and activate a venv (optional)
python -m venv .venv && source .venv/bin/activate  # on Windows: .venv\Scripts\activate

# install deps
pip install -r requirements.txt

# run API
uvicorn backend.main:app --reload --port 8000
```

In a second terminal:

```bash
streamlit run frontend/streamlit_app.py
```

Open the printed local URL. Change the API URL in the UI if needed.

## API

`POST /clarify`

```json
{
  "problem": "string",
  "context": "string | null",
  "role": "developer | pm | qa | data scientist | null"
}
```

Response includes `ambiguity_score`, `questions[]`, and `extracted_facts`.
