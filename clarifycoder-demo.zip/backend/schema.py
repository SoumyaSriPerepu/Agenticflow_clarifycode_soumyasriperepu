from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class ClarifyRequest(BaseModel):
    problem: str = Field(..., description="User problem statement")
    context: Optional[str] = Field(None, description="Optional code/context")
    role: Optional[str] = Field(None, description="Stakeholder role, e.g., 'developer', 'PM'")

class Clarification(BaseModel):
    question: str
    rationale: str
    category: str  # e.g., "ambiguity", "incompleteness", "constraints"
    priority: float  # 0..1

class ClarifyResponse(BaseModel):
    needs_clarification: bool
    ambiguity_score: float
    questions: List[Clarification]
    extracted_facts: Dict[str, Any] = {}
