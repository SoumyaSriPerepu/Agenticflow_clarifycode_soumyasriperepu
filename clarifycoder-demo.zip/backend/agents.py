import re
from typing import List, Dict, Any
from dataclasses import dataclass

AMBIGUOUS_TERMS = {
    "fast", "quick", "soon", "robust", "simple", "easy", "scalable",
    "secure", "lightweight", "optimize", "flexible", "high quality"
}

@dataclass
class Analysis:
    ambiguity_score: float
    extracted_facts: Dict[str, Any]

class ContextAnalysisAgent:
    def analyze(self, problem: str, context: str | None) -> Analysis:
        text = f"{problem}\n{context or ''}".lower()
        amb_hits = sum(t in text for t in AMBIGUOUS_TERMS)
        tbd = len(re.findall(r"\b(tbd|etc|and so on|asap)\b", text))
        missing_nums = len(re.findall(r"\b\d+\b", text)) == 0  # no numbers often implies vagueness
        ambiguity_score = min(1.0, (amb_hits * 0.12) + (tbd * 0.2) + (0.15 if missing_nums else 0))

        langs = re.findall(r"\b(python|javascript|java|go|rust|c\+\+|c#)\b", text)
        frameworks = re.findall(r"\b(flask|fastapi|django|react|streamlit|node|spring)\b", text)

        extracted = {
            "languages": sorted(set(langs)),
            "frameworks": sorted(set(frameworks)),
            "mentions_auth": bool(re.search(r"auth|login|oauth|jwt", text)),
            "mentions_data": bool(re.search(r"database|db|sql|postgres|mongodb|csv", text))
        }
        return Analysis(ambiguity_score=ambiguity_score, extracted_facts=extracted)

class StakeholderModelingAgent:
    def classify(self, role: str | None) -> str:
        if not role:
            return "developer"
        role = role.lower()
        if "pm" in role or "product" in role: return "pm"
        if "qa" in role or "test" in role: return "qa"
        if "data" in role: return "data scientist"
        return "developer"

class ClarificationGeneratorAgent:
    def generate(self, problem: str, analysis: Analysis, role: str) -> List[Dict[str, Any]]:
        q: List[Dict[str, Any]] = []
        def add(question: str, rationale: str, category: str, p: float):
            q.append({"question": question, "rationale": rationale, "category": category, "priority": p})

        # Always clarify inputs/outputs
        add("What are the exact inputs, outputs, and an example I/O pair?",
            "Unspecified I/O is a primary source of misimplementation.", "incompleteness", 0.95)

        # Ambiguity terms
        if analysis.ambiguity_score > 0.2:
            add("You mention qualitative terms (e.g., fast/robust). Can you provide numeric targets (latency, throughput, error rate)?",
                "Turns qualitative claims into testable constraints.", "ambiguity", 0.9)

        # Data & persistence
        if analysis.extracted_facts.get("mentions_data"):
            add("What data store and schema should be used? Do we need migrations or seed data?",
                "Clarifies persistence boundary and ops work.", "constraints", 0.8)
        else:
            add("Is any data persisted? If so, which store and retention/window?",
                "Avoids hidden stateful coupling.", "constraints", 0.7)

        # Auth/Security
        if analysis.extracted_facts.get("mentions_auth"):
            add("What auth method is required (OAuth2/JWT/session)? What roles and permissions exist?",
                "Security holes often come from assumption mismatches.", "security", 0.85)
        else:
            add("Are there authentication/authorization requirements or PII handling constraints?",
                "Decide security posture early.", "security", 0.75)

        # Interfaces
        add("What is the integration surface (CLI, REST, gRPC, UI)? Provide one canonical call/flow.",
            "Defines boundary and demo scenario.", "interface", 0.85)

        # Non-functionals
        add("What are the non-functional requirements? (SLOs, max cost/month, supported regions, browsers)",
            "Prevents surprise rework later.", "quality", 0.8)

        # Acceptance
        add("What acceptance tests or success metrics should we pass to consider this done?",
            "Anchors implementation to measurable outcomes.", "validation", 0.9)

        # Domain-specific
        if role == "data scientist":
            add("What is the labeling source, expected dataset size, and offline/online evaluation protocol?",
                "DS tasks fail without eval clarity.", "ml", 0.8)

        return q

class ContinualLearningAgent:
    def rank_and_select(self, questions: List[Dict[str, Any]], k: int = 8) -> List[Dict[str, Any]]:
        return sorted(questions, key=lambda x: (-x["priority"], x["category"]))[:k]
