from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .schema import ClarifyRequest, ClarifyResponse, Clarification
from .agents import ContextAnalysisAgent, StakeholderModelingAgent, ClarificationGeneratorAgent, ContinualLearningAgent

app = FastAPI(title="ClarifyCoder Demo API", version="0.1")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

context_agent = ContextAnalysisAgent()
stake_agent = StakeholderModelingAgent()
clar_agent = ClarificationGeneratorAgent()
learn_agent = ContinualLearningAgent()

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/clarify", response_model=ClarifyResponse)
def clarify(req: ClarifyRequest):
    analysis = context_agent.analyze(req.problem, req.context)
    role = stake_agent.classify(req.role)
    qs = clar_agent.generate(req.problem, analysis, role)
    ranked = learn_agent.rank_and_select(qs)
    needs = True if analysis.ambiguity_score > 0.05 else len(ranked) > 0
    return ClarifyResponse(
        needs_clarification=needs,
        ambiguity_score=analysis.ambiguity_score,
        questions=[Clarification(**q) for q in ranked],
        extracted_facts=analysis.extracted_facts,
    )
