import streamlit as st
import requests
import os

API_URL = os.getenv("CLARIFY_API_URL", "http://localhost:8000")

st.set_page_config(page_title="ClarifyCoder Demo", layout="centered")
st.title("🔎 ClarifyCoder Demo")

with st.expander("Configure", expanded=False):
    api = st.text_input("API URL", API_URL, help="FastAPI endpoint base URL")
    st.session_state["api"] = api

st.write("Enter a problem and optional context. The demo will propose clarification questions.")

problem = st.text_area("Problem statement", height=160, placeholder="e.g., Build a fast, secure API for uploading images and tagging them.")
context = st.text_area("Context (optional)", height=120, placeholder="e.g., We use Python + FastAPI; deploy to GCP Cloud Run; Postgres available.")
role = st.selectbox("Your role", ["developer", "pm", "qa", "data scientist"])

if st.button("Generate Clarifications", type="primary"):
    try:
        r = requests.post(f"{st.session_state['api']}/clarify", json={
            "problem": problem, "context": context, "role": role
        }, timeout=20)
        r.raise_for_status()
        data = r.json()
        st.success(f"Ambiguity score: {data['ambiguity_score']:.2f}  •  Needs clarification: {data['needs_clarification']}")
        st.subheader("Proposed Questions")
        for i, q in enumerate(data["questions"], start=1):
            with st.container():
                st.markdown(f"**{i}. {q['question']}**")
                st.caption(f"{q['category']} • priority {q['priority']:.2f}")
                with st.expander("Why this?"):
                    st.write(q["rationale"])
        st.subheader("Extracted Facts")
        st.json(data["extracted_facts"])
    except Exception as e:
        st.error(f"Failed to contact API: {e}")

st.markdown("---")
st.markdown("**How to run locally**")
st.code("""
# 1) In one terminal:
uvicorn backend.main:app --reload --port 8000

# 2) In another terminal:
streamlit run frontend/streamlit_app.py
""", language="bash")
